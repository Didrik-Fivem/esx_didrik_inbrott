INSERT INTO `items` (name, label) VALUES 
	('rolex', 'Klocka'),
	('ring', 'Ring'),
	('kamera', 'Kamera'),
	('armband', 'Armband'),
	('halsband', 'Halsband')
;