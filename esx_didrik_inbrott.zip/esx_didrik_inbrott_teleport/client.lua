local TeleportFromTo = {
	["Police HeliPad"] = { 
		positionFrom = { ['x'] = 919.7, ['y'] = -569.5, ['z'] = 58.4, nom = "~w~Tryck [~g~E~w~] för att ~r~bryta ~w~dig in i huset"},
		positionTo = { ['x'] = 346.5, ['y'] = -1013.1, ['z'] = -99.15, nom = "~w~Tryck [~g~E~w~] ~w~för att gå ut"},
	},	
}

ESX = nil

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

RegisterNetEvent('lucas')
AddEventHandler('lucas', function(x, y)
    SetNewWaypoint(x, y)
end)

Drawing = setmetatable({}, Drawing)
Drawing.__index = Drawing


function Drawing.draw3DText(x,y,z,textInput,fontId,scaleX,scaleY,r, g, b, a)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)

    local scale = (1/dist)*20
    local fov = (1/GetGameplayCamFov())*100
    local scale = scale*fov

    SetTextScale(scaleX*scale, scaleY*scale)
    SetTextFont(fontId)
    SetTextProportional(1)
    SetTextColour(r, g, b, a)
    SetTextDropshadow(0, 0, 0, 0, 255)
    SetTextEdge(2, 0, 0, 0, 150)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(textInput)
    SetDrawOrigin(x,y,z+2, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

function Drawing.drawMissionText(m_text, showtime)
    ClearPrints()
    SetTextEntry_2("STRING")
    AddTextComponentString(m_text)
    DrawSubtitleTimed(showtime, 1)
end

function msginf(msg, duree)
    duree = duree or 500
    ClearPrints()
    SetTextEntry_2("STRING")
    AddTextComponentString(msg)
    DrawSubtitleTimed(duree, 1)
end


RegisterNetEvent("mt:missiontext") 
AddEventHandler("mt:missiontext", function(text, time)
        ClearPrints()
        SetTextEntry_2("STRING")
        AddTextComponentString(text)
        DrawSubtitleTimed(time, 1)
end)

------------------ UTOMHUS ----------------------

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)
	while true do
		Citizen.Wait(2)
		local pos = GetEntityCoords(GetPlayerPed(-1), true)

		for k, j in pairs(TeleportFromTo) do

			--msginf(k .. " " .. tostring(j.positionFrom.x), 15000)
			if(Vdist(pos.x, pos.y, pos.z, j.positionFrom.x, j.positionFrom.y, j.positionFrom.z) < 150.0)then
				DrawMarker(27, j.positionFrom.x, j.positionFrom.y, j.positionFrom.z - 1, 0, 0, 0, 0, 0, 0, 1.2001, 1.2001, 0.801, 255, 0, 0, 231, 0, 0, 0,0)
				if(Vdist(pos.x, pos.y, pos.z, j.positionFrom.x, j.positionFrom.y, j.positionFrom.z) < 5.0)then
					Drawing.draw3DText(j.positionFrom.x, j.positionFrom.y, j.positionFrom.z - 1.100, j.positionFrom.nom, 6, 0.2, 0.1, 255, 255, 255, 215)
					if(Vdist(pos.x, pos.y, pos.z, j.positionFrom.x, j.positionFrom.y, j.positionFrom.z) < 2.0)then
						if IsControlJustPressed(1, 38) then
						    ESX.TriggerServerCallback('esx_didrik_rob:getPolice', function(police) 
						     	if police >= Config.NumberOfCopsRequired then		


									local pP = GetPlayerPed(-1)
									TaskPlayAnim(pP, "WORLD_HUMAN_HAMMERING", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            		TaskStartScenarioInPlace(pP, "WORLD_HUMAN_HAMMERING", 0, true)
                            		TriggerServerEvent("InteractSound_SV:PlayWithinDistance", 8, "inbrott", 0.1)
	                                TimeLeft = Config.TimeToPackBox
	                                repeat                                	
	                                TriggerEvent("mt:missiontext", 'Du ~r~bryter~w~ dig in. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                                TimeLeft = TimeLeft - 1
	                                Citizen.Wait(1000)
	                                until(TimeLeft == 0)
									DoScreenFadeOut(1000)
									Citizen.Wait(2000)
									SetEntityCoords(GetPlayerPed(-1), j.positionTo.x, j.positionTo.y, j.positionTo.z - 1)
									DoScreenFadeIn(1000)
									SetTextEntry_2("STRING")
						    		AddTextComponentString("~g~Bra jobbat.~w~, Du tog dig in. ~b~Polisen~w~ larmas till ~r~platsen~w~ snart.")
						    		DrawSubtitleTimed(9000, 1)
									Citizen.Wait(10000) 
									TriggerServerEvent('esx_didrik_inbrott:larm')
								else 
									ClearPrints()
									SetTextEntry_2("STRING")
									AddTextComponentString("Det är ~r~inte~w~ tillräckligt med ~b~poliser~w~ i tjänst, Det är "..police.. " ~b~poliser~w~ i ~r~tjänst~w~!")
						    		DrawSubtitleTimed(4000, 1)
								end	
							end)
						end
					end
				end
			end

--------------- INOMHUS -----------------

			if(Vdist(pos.x, pos.y, pos.z, j.positionTo.x, j.positionTo.y, j.positionTo.z) < 150.0)then
				DrawMarker(27, j.positionTo.x, j.positionTo.y, j.positionTo.z - 1, 0, 0, 0, 0, 0, 0, 1.2001, 1.2001, 0.801, 255, 0, 0, 231, 0, 0, 0,0)
				if(Vdist(pos.x, pos.y, pos.z, j.positionTo.x, j.positionTo.y, j.positionTo.z) < 5.0)then
					Drawing.draw3DText(j.positionTo.x, j.positionTo.y, j.positionTo.z - 1.100, j.positionTo.nom, 6, 0.2, 0.1, 255, 255, 255, 215)
					if(Vdist(pos.x, pos.y, pos.z, j.positionTo.x, j.positionTo.y, j.positionTo.z) < 2.0)then
						ClearPrints()
						if IsControlJustPressed(1, 38) then
							DoScreenFadeOut(1000)
							Citizen.Wait(2000)
							SetEntityCoords(GetPlayerPed(-1), j.positionFrom.x, j.positionFrom.y, j.positionFrom.z - 1)
							SetTextEntry_2("STRING")
						    AddTextComponentString("~g~Bra jobbat~w~, Du ~r~tog~w~ dig ut.")
						    DrawSubtitleTimed(9000, 1)
							DoScreenFadeIn(1000)
						end
					end
				end
			end
		end
	end
end)
