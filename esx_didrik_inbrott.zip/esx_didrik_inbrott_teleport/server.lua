local rob = false
local robbers = {}
ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


function CountPolices()

	local xPlayers = ESX.GetPlayers()

	police = 0

	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		if xPlayer.job.name == 'police' then
			police = police + 1
		end
	end
end

ESX.RegisterServerCallback('esx_didrik_rob:getPolice', function(source, cb)

	local xPlayer = ESX.GetPlayerFromId(source)

	CountPolices()

	cb(police)

end)

RegisterServerEvent('esx_didrik_inbrott:larm')
AddEventHandler('esx_didrik_inbrott:larm', function()
 
local xPlayers = ESX.GetPlayers()

    for player = 1, #xPlayers, 1 do
        local newxPlayer = ESX.GetPlayerFromId(xPlayers[player])

        if newxPlayer ~= nil then
            if newxPlayer.job.name == 'police' then
            	TriggerClientEvent('lucas', newxPlayer.source, 919.6, -569.6)
                TriggerClientEvent('esx:showNotification', newxPlayer.source, 'Pågående inbrott, GPS:Destination är tillagd i eran GPS. Skynda er.')
            end
        end
    end
end)    
