Config = {}
Config.NumberOfCopsRequired = 1
Config.TimeToPackBox			  = 20 -- Sekunder