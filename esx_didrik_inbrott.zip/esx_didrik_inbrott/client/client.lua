local Keys = {
	["ESC"] = 322, ["F1"] = 288, ["F2"] = 289, ["F3"] = 170, ["F5"] = 166, ["F6"] = 167, ["F7"] = 168, ["F8"] = 169, ["F9"] = 56, ["F10"] = 57, 
	["~"] = 243, ["1"] = 157, ["2"] = 158, ["3"] = 160, ["4"] = 164, ["5"] = 165, ["6"] = 159, ["7"] = 161, ["8"] = 162, ["9"] = 163, ["-"] = 84, ["="] = 83, ["BACKSPACE"] = 177, 
	["TAB"] = 37, ["Q"] = 44, ["W"] = 32, ["E"] = 38, ["R"] = 45, ["T"] = 245, ["Y"] = 246, ["U"] = 303, ["P"] = 199, ["["] = 39, ["]"] = 40, ["ENTER"] = 18,
	["CAPS"] = 137, ["A"] = 34, ["S"] = 8, ["D"] = 9, ["F"] = 23, ["G"] = 47, ["H"] = 74, ["K"] = 311, ["L"] = 182,
	["LEFTSHIFT"] = 21, ["Z"] = 20, ["X"] = 73, ["C"] = 26, ["V"] = 0, ["B"] = 29, ["N"] = 249, ["M"] = 244, [","] = 82, ["."] = 81,
	["LEFTCTRL"] = 36, ["LEFTALT"] = 19, ["SPACE"] = 22, ["RIGHTCTRL"] = 70, 
	["HOME"] = 213, ["PAGEUP"] = 10, ["PAGEDOWN"] = 11, ["DELETE"] = 178,
	["LEFT"] = 174, ["RIGHT"] = 175, ["TOP"] = 27, ["DOWN"] = 173,
	["NENTER"] = 201, ["N4"] = 108, ["N5"] = 60, ["N6"] = 107, ["N+"] = 96, ["N-"] = 97, ["N7"] = 117, ["N8"] = 61, ["N9"] = 118
}

ESX = nil
local PlayerData              = {}
local inbrott = false
local didrik = true
local pP = GetPlayerPed(-1)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

function DisplayHelpText(str)
	SetTextComponentFormat("STRING")
	AddTextComponentString(str)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

function msginf(msg, duree)
    duree = duree or 500
    ClearPrints()
    SetTextEntry_2("STRING")
    AddTextComponentString(msg)
    DrawSubtitleTimed(duree, 1)
end

RegisterNetEvent("mt:missiontext") -- Original script: https://github.com/schneehaze/fivem_missiontext/blob/master/MissionText/missiontext.lua
AddEventHandler("mt:missiontext", function(text, time)
        ClearPrints()
        SetTextEntry_2("STRING")
        AddTextComponentString(text)
        DrawSubtitleTimed(time, 1)
end)

function Draw3DText(x, y, z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)
 
    local scale = 0.3
   
    if onScreen then
        SetTextScale(scale, scale)
        SetTextFont(0)
        SetTextProportional(1)
        -- SetTextScale(0.0, 0.55)
        SetTextColour(255, 255, 255, 255)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x,_y)
    end
end

function drawTxt(x,y ,width,height,scale, text, r,g,b,a, outline)
    SetTextFont(0)
    SetTextProportional(0)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextEdge(1, 0, 0, 0, 255)
    SetTextDropShadow()
    if(outline)then
	    SetTextOutline()
	end
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x - width/2, y - height/2 + 0.005)
end

function DrawText3D(x, y, z, text, scale)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local pX, pY, pZ = table.unpack(GetGameplayCamCoords())
 
    SetTextScale(scale, scale)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextEntry("STRING")
    SetTextCentre(1)
    SetTextColour(255, 255, 255, 215)
 
    AddTextComponentString(text)
    DrawText(_x, _y)
 
    local factor = (string.len(text)) / 370
 
    DrawRect(_x, _y + 0.0250, 0.095 + factor, 0.06, 41, 11, 41, 100)
end

function hintToDisplay(text)
	SetTextComponentFormat("STRING")
	AddTextComponentString(text)
	DisplayHelpTextFromStringLabel(0, 0, 1, -1)
end

function Draw(text, r, g, b, alpha, x, y, width, height, layer, center, font)
	SetTextColour(r, g, b, alpha)
	SetTextFont(font)
	SetTextScale(width, height)
	SetTextWrap(0.0, 1.0)
	SetTextCentre(center)
	SetTextDropshadow(0, 0, 0, 0, 0)
	SetTextEdge(1, 0, 0, 0, 205)
	SetTextEntry('STRING')
	AddTextComponentSubstringPlayerName(text)
	Set_2dLayer(layer)
	DrawText(x, y)
end




------------------------ INBROTT MARKERS ------------------------

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
		PlayerData = ESX.GetPlayerData()
	end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
  PlayerData.job = job
end)

RegisterNetEvent('esx_didrik_inbrott:trueMembership')
AddEventHandler('esx_didrik_inbrott:trueMembership', function()
	membership = false
end)

RegisterNetEvent('esx_gym:falseMembership')
AddEventHandler('esx_gym:falseMembership', function()
	membership = false
end)

-- Lokala ställen (START)

local koksbord = {
    {x = 339.2,y = -1003.4,z = -99.6}
}

local tvhylla = {
    {x = 338.1,y = -994.9,z = -99.6}
}

local hallhylla = {
    {x = 345.4,y = -995.7,z = -99.6}
}

local garderob = {
    {x = 351.2,y = -993.5,z = -99.6}
}

local nattduksbord = {
    {x = 349.2,y = -994.8,z = -99.6}
}

local hallbank = {
    {x = 346.0,y = -1001.6,z = -99.6}
}

local koksbank = {
    {x = 342.3,y = -1003.2,z = -99.6}
}

local bord = {
    {x = 341.4,y = -997.2,z = -99.6}
}

local handfat = {
    {x = 347.2,y = -994.2,z = -99.6}
}

------------------------ KÖKSBORDET ------------------------

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)
    while true do
        Citizen.Wait(0)

        for k in pairs(koksbord) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, koksbord[k].x, koksbord[k].y, koksbord[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveKlocka') 										
						end
					end
				end			
            end
        end
    end
end)

------------------------ HANDFAT ------------------------

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)
    while true do
        Citizen.Wait(0)

        for k in pairs(handfat) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, handfat[k].x, handfat[k].y, handfat[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveArmband') 									
						end
					end
				end			
            end
        end
    end
end)

------------------------ BORDET ------------------------

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)
    while true do
        Citizen.Wait(0)

        for k in pairs(bord) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, bord[k].x, bord[k].y, bord[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveKlocka') 									
						end
					end
				end			
            end
        end
    end
end)

------------------------ TV-HYLLAN ------------------------

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)
    while true do
        Citizen.Wait(0)

        for k in pairs(tvhylla) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, tvhylla[k].x, tvhylla[k].y, tvhylla[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveRing')								
						end
					end
				end			
            end
        end
    end
end)

------------------------ HALL-HYLLAN ------------------------

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)	
    while true do
        Citizen.Wait(0)

        for k in pairs(hallhylla) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, hallhylla[k].x, hallhylla[k].y, hallhylla[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveKamera')									
						end
					end
				end			
            end
        end
    end
end)

------------------------ GARDEROB ------------------------

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)	
    while true do
        Citizen.Wait(0)

        for k in pairs(garderob) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, garderob[k].x, garderob[k].y, garderob[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	 
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveHalsband')								
						end
					end
				end			
            end
        end
    end
end)

------------------------ NATTDUKSBORD ------------------------ 

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)	
    while true do
        Citizen.Wait(0)

        for k in pairs(nattduksbord) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, nattduksbord[k].x, nattduksbord[k].y, nattduksbord[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveArmband')									
						end
					end
				end			
            end
        end
    end
end)

------------------------ HALLBANK ------------------------ 

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)	
    while true do
        Citizen.Wait(0)

        for k in pairs(hallbank) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, hallbank[k].x, hallbank[k].y, hallbank[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveArmband')								
						end
					end
				end			
            end
        end
    end
end)

------------------------ KOKSBANK ------------------------ 

Citizen.CreateThread(function()
	local pP = GetPlayerPed(-1)	
    while true do
        Citizen.Wait(0)

        for k in pairs(koksbank) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, koksbank[k].x, koksbank[k].y, koksbank[k].z)

            if dist <= 0.5 then
				
				if IsControlJustPressed(0, Keys['E']) then
					if inbrott == false then
					
						TriggerServerEvent('esx_didrik_inbrott:checkChip')	
						Citizen.Wait(1000)					
					    
						if membership == false then
							local pP = GetPlayerPed(-1)
							TaskPlayAnim(pP, "amb@prop_human_bum_bin@enter", "enter", 3.5, -8, -1, 2, 0, 0, 0, 0, 0)
                            TaskStartScenarioInPlace(pP, "PROP_HUMAN_BUM_BIN", 0, true)	
                            TimeLeft = Config.TimeToPackBox
	                        repeat                                	
	                        TriggerEvent("mt:missiontext", 'Du ~g~letar~w~ efter ~r~stöldgods~w~. Tid kvar: ~r~' .. TimeLeft .. ' ~w~sekunder', 1000)
	                        TimeLeft = TimeLeft - 1
	                        Citizen.Wait(1000)
	                        until(TimeLeft == 0)
							ClearPedTasksImmediately(pP)
							TriggerServerEvent('esx_didrik_inbrott:giveRing')									
						end
					end
				end			
            end
        end
    end
end)

------------------------ 3D-TEXTER, KÖKSBORDER ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 339.2, -1003.4, -99.1, true) <= 3.5 then
            Draw3DText(339.2, -1003.4, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ 3D-TEXTER, HANDFAT ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 347.2, -994.2, -99.1, true) <= 3.5 then
            Draw3DText(347.2, -994.2, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ 3D-TEXTER, TV-HYLLAN ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 338.1, -994.94, -99.1, true) <= 3.5 then
            Draw3DText(338.1, -994.94, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ 3D-TEXTER, HALL-HYLLAN ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 345.4, -995.7, -99.1, true) <= 3.5 then
            Draw3DText(345.4, -995.7, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ 3D-TEXTER, GARDEROBEN ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 351.2, -993.5, -99.1, true) <= 3.5 then
            Draw3DText(351.2, -993.5, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ 3D-TEXTER, NATTDUKSBORDET ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 349.2, -994.8, -99.1, true) <= 3.5 then
            Draw3DText(349.2, -994.8, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ 3D-TEXTER, HALLBÄNK ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 346.0, -1001.6, -99.1, true) <= 3.5 then
            Draw3DText(346.0, -1001.6, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ 3D-TEXTER, KÖKSBÄNK ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 342.3, -1003.2, -99.1, true) <= 3.5 then
            Draw3DText(342.3, -1003.2, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ 3D-TEXTER, BORD ------------------------ 

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 341.4, -997.2, -99.1, true) <= 3.5 then
            Draw3DText(341.4, -997.2, -99.1, 'Tryck på [~g~E~w~] för att leta efter ~r~stöldgods~w~.')
        end
    end
end)

------------------------ BLIPS ------------------------ 

--- Inbrotts Blip
Citizen.CreateThread(function()
    local blip = AddBlipForCoord(920.1, -570.5, 58.3)

    SetBlipSprite (blip, 461)
    SetBlipDisplay(blip, 4)
    SetBlipScale  (blip, 0.8)
    SetBlipColour (blip, 17)
    SetBlipAsShortRange(blip, true)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString('Inbrott')
    EndTextCommandSetBlipName(blip)
end)

--- Försäljnings Blip
Citizen.CreateThread(function()
    local blip = AddBlipForCoord(1023.6, -1725.5, 35.6)

    SetBlipSprite (blip, 431)
    SetBlipDisplay(blip, 4)
    SetBlipScale  (blip, 0.8)
    SetBlipColour (blip, 17)
    SetBlipAsShortRange(blip, true)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString('Försäljning av stöldgods')
    EndTextCommandSetBlipName(blip)
end)

------------------------ FÖRSÄLJNING ------------------------

Citizen.CreateThread(function()
    while true do Citizen.Wait(0)
        if (GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 1023.5, -1725.6, 35.6, true) <= 2.1 ) then
            if IsControlPressed(0, Keys['E']) then
                if not selling then
                    selling = true
                    TriggerServerEvent('esx_didrik_inbrott:startSell')
                    Wait(2000)
                    selling = false
                end
            end
        end
    end
end)


------------------------ 3D-TEXTER & MARKERS, FÖRSÄLJNING ------------------------

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(1)
        if (GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 1023.5, -1725.6, 34.7, true) <= 1000 ) then
            DrawMarker(27,1023.5, -1725.6, 34.7, 0, 0, 0, 0, 0, 0, 2.001, 2.0001, 0.5001, 246, 255, 0, 200, 0, 0, 0, 0)
        end
         if GetDistanceBetweenCoords(GetEntityCoords(GetPlayerPed(-1)), 1023.5, -1725.6, 36.2, true) <= 6.5 then
            Draw3DText(1023.5, -1725.6, 36.2, 'Tryck [~g~E~w~] för att sälja ditt ~r~stöldgods~w~')
        end
    end
end)

------------------------
