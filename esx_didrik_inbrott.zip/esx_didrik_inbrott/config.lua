Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 5 -- Cops needed to be online
Config.TextCoords = { x = 352.5, y = -998.7, z = -98.80} -- Money text coordinates
Config.MoneyCoords = { x = 352.5, y = -998.7, z = -99.62} -- Money coordinates
Config.StartMoney = 4500 -- The money that shows when server start
Config.MinCash = 850 -- Min you can take per 3 seconds
Config.MaxCash = 1250 -- Max you can take per 3 seconds
Config.MaxMoney = 4000 -- Max everyone can fill bag
Config.NumberOfCopsRequired = 0
Config.TimeToPackBox			  = 10 -- Sekunder