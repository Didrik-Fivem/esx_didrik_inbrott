local rob = false
local robbers = {}
local src = source
PlayersHarvesting  = {}
PlayersCrafting    = {}
ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

function get3DDistance(x1, y1, z1, x2, y2, z2)
	return math.sqrt(math.pow(x1 - x2, 2) + math.pow(y1 - y2, 2) + math.pow(z1 - z2, 2))
end


RegisterServerEvent('esx_didrik_inbrott:checkChip')
AddEventHandler('esx_didrik_inbrott:checkChip', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local oneQuantity = xPlayer.getInventoryItem('bread').count
	
	if oneQuantity > 0 then
		TriggerClientEvent('esx_didrik_inbrott:trueMembership', source) -- true
	else
		TriggerClientEvent('esx_didrik_inbrott:trueMembership', source) -- false
	end
end)



RegisterServerEvent('esx_didrik_inbrott:giveKlocka')
AddEventHandler('esx_didrik_inbrott:giveKlocka', function()
 
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local luck = math.random(0, 50)
    local randomKlocka = math.random(1, 3)
 
    if luck >= 0 and luck <= 35 then
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ~r~inget~w~, Leta bättre nästa gång.')
    end
    if luck >= 35 and luck < 50 then
        xPlayer.addInventoryItem('rolex', randomKlocka )
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ' ..randomKlocka.. ' st föremål.')
    end
end)



RegisterServerEvent('esx_didrik_inbrott:giveRing')
 AddEventHandler('esx_didrik_inbrott:giveRing', function()
 
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local luck = math.random(0, 50)
    local randomRing = math.random(1, 3)
 
    if luck >= 0 and luck <= 35 then
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ~r~inget~w~, Leta bättre nästa gång.')
    end
    if luck >= 35 and luck < 50 then
        xPlayer.addInventoryItem('ring', randomRing )
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ' ..randomRing.. ' st föremål.')
    end
end)



RegisterServerEvent('esx_didrik_inbrott:giveKamera')
AddEventHandler('esx_didrik_inbrott:giveKamera', function()
 
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local luck = math.random(0, 50)
    local randomKamera = math.random(1, 3)
 
    if luck >= 0 and luck <= 35 then
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ~r~inget~w~, Leta bättre nästa gång.')
    end
    if luck >= 35 and luck < 50 then
        xPlayer.addInventoryItem('kamera', randomKamera )
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ' ..randomKamera.. ' st föremål.')
    end
end)



RegisterServerEvent('esx_didrik_inbrott:giveHalsband')
AddEventHandler('esx_didrik_inbrott:giveHalsband', function()
 
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local luck = math.random(0, 50)
    local randomHalsband = math.random(1, 3)
 
    if luck >= 0 and luck <= 35 then
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ~r~inget~w~, Leta bättre nästa gång.')
    end
    if luck >= 35 and luck < 50 then
        xPlayer.addInventoryItem('halsband', randomHalsband )
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ' ..randomHalsband.. ' st föremål.')
    end
end)



RegisterServerEvent('esx_didrik_inbrott:giveArmband')
AddEventHandler('esx_didrik_inbrott:giveArmband', function()
 
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    local luck = math.random(0, 50)
    local randomArmband = math.random(1, 3)
 
    if luck >= 0 and luck <= 35 then
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ~r~inget~w~, Leta bättre nästa gång.')
    end
    if luck >= 35 and luck < 50 then
        xPlayer.addInventoryItem('armband', randomArmband )
        TriggerClientEvent("esx:showNotification", source, 'Du hittade ' ..randomArmband.. ' st föremål.')
    end
end)


local function Craft(source)

    SetTimeout(4000, function()

        if PlayersCrafting[source] == true then

            local xPlayer  = ESX.GetPlayerFromId(source)
            local RolexQuantity = xPlayer.getInventoryItem('rolex').count
            local RingQuantity = xPlayer.getInventoryItem('ring').count  
            local KameraQuantity = xPlayer.getInventoryItem('kamera').count    
            local HalsbandQuantity = xPlayer.getInventoryItem('halsband').count   
            local ArmbandQuantity = xPlayer.getInventoryItem('armband').count                              
            local randomNumber = math.random(50, 85)

            if RolexQuantity <= 0 then
                TriggerClientEvent('esx:showNotification', source, 'Du har ingen ~r~Rolex~w~.')            
            else   
                xPlayer.removeInventoryItem('rolex', RolexQuantity)
                xPlayer.addMoney(randomNumber * RolexQuantity)
                TriggerClientEvent('esx:showNotification', source, 'Du sålde din ~r~Rolex.') 
            end    

            if RingQuantity <= 0 then
                TriggerClientEvent('esx:showNotification', source, 'Du har ingen ~r~Ring~w~.')  
            else   
                xPlayer.removeInventoryItem('ring', RingQuantity)
                xPlayer.addMoney(randomNumber * RingQuantity)
                TriggerClientEvent('esx:showNotification', source, 'Du sålde din ~r~Ring.') 
            end
                
            if KameraQuantity <= 0 then
                TriggerClientEvent('esx:showNotification', source, 'Du har ingen ~r~Kamera~w~.')  
            else   
                xPlayer.removeInventoryItem('kamera', KameraQuantity)
                xPlayer.addMoney(randomNumber * KameraQuantity)
                TriggerClientEvent('esx:showNotification', source, 'Du sålde din ~r~Kamera.') 
            end

            if HalsbandQuantity <= 0 then
                TriggerClientEvent('esx:showNotification', source, 'Du har inget ~r~Halsband~w~.')  
            else   
                xPlayer.removeInventoryItem('halsband', HalsbandQuantity)
                xPlayer.addMoney(randomNumber * HalsbandQuantity)
                TriggerClientEvent('esx:showNotification', source, 'Du sålde ditt ~r~Halsband.') 
            end

            if ArmbandQuantity <= 0 then
                TriggerClientEvent('esx:showNotification', source, 'Du har inget ~r~Armband~w~.')  
            else   
                xPlayer.removeInventoryItem('armband', ArmbandQuantity)
                xPlayer.addMoney(randomNumber * ArmbandQuantity)
                TriggerClientEvent('esx:showNotification', source, 'Du sålde ditt ~r~Armband.')     
                
                Craft(source)
            end
        end
    end)
end

RegisterServerEvent('esx_didrik_inbrott:startSell')
AddEventHandler('esx_didrik_inbrott:startSell', function()
    local _source = source
    PlayersCrafting[_source] = true
    TriggerClientEvent('esx:showNotification', _source, 'Påbörjar försäljning av ditt ~r~stöldgods.')
    Craft(_source)
end)

RegisterServerEvent('esx_didrik_inbrott:stopSell')
AddEventHandler('esx_didrik_inbrott:stopSell', function()
    local _source = source
    PlayersCrafting[_source] = false
end)