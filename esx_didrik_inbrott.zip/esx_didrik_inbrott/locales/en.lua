Locales['en'] = {

	['bank_robbery'] = 'Swedbank Rån',
	['press_to_rob'] = 'Tryck ~INPUT_CONTEXT~ för att koppla in din ~r~mobil ~b~',
	['robbery_of'] = '~r~Du har~s~: ~r~',
	['seconds_remaining'] = '~w~ sekunder kvar innan larmet går',
	['robbery_cancelled_at'] = '~r~ Rånet avbrutet påt: ~b~',
	['robbery_has_cancelled'] = '~r~ Rånet har avbrutits på: ~b~',
	['already_robbed'] = 'Banken har redan blivit rånad vänta: ',
	['seconds'] = 'seconds.',
	['rob_in_prog'] = '~r~Rån pågår på: ~b~',
	['started_to_rob'] = 'Ta så mycket ~r~cash~s~ som du hinner!',
	['do_not_move'] = ', do not move away!',
	['alarm_triggered'] = 'the alarm has been triggered',
	['robbery_complete_at'] = '~r~ Bankrån Klart på: ~b~',
	['min_two_police'] = 'Minst: ',
	['money'] = 'Kontanter: ~g~',
	['take_money'] =  'Tryck ~INPUT_CONTEXT~ för att ~g~ta~s~ pengarna.',
}
